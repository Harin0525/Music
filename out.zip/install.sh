#!/bin/sh

R='\x1b[1;31m'
G='\x1b[1;32m'
B='\x1b[1;34m'
Y='\x1b[1;33m'
C='\x1b[1;36m'
pur='\033[35;1m'
D='\x1b[0m'

function Percent(){
    message="$1"
    max=$2 
        i=0
        while [ $i -le $max ]; do
            echo -ne "\r${G}[+]${D} $message ${C}$i${D} %"
            sleep 0.03
            if [ $i -eq 100 ]; then
                echo -ne "${C} [complete!]${D}\n"
            fi
            let i++
        done
}
load(){
    echo -e "\n"
    bar=" >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> "
    barlength=${#bar}
    i=0
    while((i<100)); do
        n=$((i*barlength / 100))
        printf "\e[00;34m\r[%-${barlength}s]\e[00m" "${bar:0:n}"
        ((i += RANDOM%1+1))
        sleep 0.02
    done
}

printf $G"========================================\n"
printf $G"=         $pur  HARIN MUSIC PLAY  $G         =\n"
printf $G"========================================\n"
sleep 2
printf $C"Mohon tunggu yaaa....\n"
sleep 1
Percent "LOADING..." 100
echo 
sleep 1
printf $G"[1] lagu ke 1...\n"
sleep 1
printf $B"[2] lagu ke 2...\n"
sleep 1
printf $R"[3] lagu ke 3...\n"
sleep 1
printf $Y"[4] lagu ke 4...\n"
sleep 1
printf $C"[5] lagu ke 5...\n"
sleep 1
printf $G"[6] lagu ke 6...\n"
   read -p "masukan lokasi lagu? " lagu
	if [ $lagu = 1 ]
	   then
	      mpv /Harin/lagu1.mp3
	elif [ $lagu = 2 ]
	   then
	      mpv /Harin/lagu2.mp3
	elif [ $lagu = 3 ]
	   then
	      mpv /Harin/lagu3.mp3
	elif [ $lagu = 4 ]
	   then
	      mpv /Harin/lagu4.mp3
	elif [ $lagu = 5 ]
	   then
	      mpv /Harin/lagu5.mp3
	elif [ $lagu = 6 ]
	   then
	      mpv /Harin/lagu6.mp3
	else
	   printf $R"maaf lagu tidak di daftar...\n"
fi
